`CPPAN=1`, `CPPAN_BUILD=1` - defined when sources are compiled under CPPAN build.

`CPPAN_EXPORT` - automatically set to proper export/import definition when building shared library on any platform.

`CPPAN_CONFIG` - string with current compiler configuration. For example, `"amd64-msvc-19.0-32"`, `"armv7-a-gnu-4.9-32"`.
